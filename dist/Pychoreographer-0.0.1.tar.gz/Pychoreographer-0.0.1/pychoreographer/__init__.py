"""Top-level package for pyChoreographer."""

__author__ = """Rajaa Lebchiri"""
__email__ = "rajaa.lebchiri@gmail.com"
__version__ = "0.1.0"
